from flask import Flask, jsonify, request
from flask_cors import CORS
from Interface import save_chat_history, graph_extension, GraphCallFunction  # 添加 GraphCallFunction 导入

app = Flask(__name__)
CORS(app, resources={
    r"/api/*": {
        "origins": ["http://localhost:8000"],  # 允许来自开发服务器的请求
        "methods": ["GET", "POST", "OPTIONS"],
        "allow_headers": ["Content-Type"]
    }
})

@app.route('/api/graph_extension', methods=['POST'])
def handle_graph_extension():
    if request.method == 'POST':
        data = request.json
        result = graph_extension(data.get('newGraph'))
        return jsonify(result)
    return jsonify({"status": "error", "message": "Method not allowed"}), 405

@app.route('/api/graph_call', methods=['POST'])
def graph_call():
    if request.method == 'POST':
        data = request.json
        result = GraphCallFunction(
            data.get('oldGraph'),
            data.get('userPrompt')
        )
        return jsonify(result)
    return jsonify({"status": "error", "message": "Method not allowed"}), 405

@app.route('/api/save_history', methods=['POST'])  # Add methods=['POST']
def save_history():
    if request.method == 'POST':
        data = request.json
        result = save_chat_history(
            data.get('userMessage'),
            data.get('aiResponse')
        )
        return jsonify(result)
    return jsonify({"status": "error", "message": "Method not allowed"}), 405

if __name__ == '__main__':
    app.run(debug=True, port=5000)  # Changed port to 5000