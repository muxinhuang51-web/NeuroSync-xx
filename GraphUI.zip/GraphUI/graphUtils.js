class GraphManager {
    constructor() {
        this.oldGraphSvg = d3.select("#oldGraph");
        this.currentGraphSvg = d3.select("#currentGraph");
        this.currentGraph = null;
        this.oldGraph = null;
        this.graphHistory = JSON.parse(localStorage.getItem('graphHistory') || '[]');
        this.versionHistory = []; // Store versions for current editing session
        this.currentVersion = 0;  // Track current version number
        this.extensionPreview = null;
        this.initExtensionPreview();

        // Add window unload event listener to save history to file
        window.addEventListener('beforeunload', () => {
            if (this.graphHistory.length > 0) {
                localStorage.setItem('graphHistory', JSON.stringify(this.graphHistory));
            }
        });
    }

    initExtensionPreview() {
        // Create extension preview element
        this.extensionPreview = document.createElement('div');
        this.extensionPreview.className = 'extension-preview';
        this.extensionPreview.innerHTML = `
            <div class="extension-preview-header">
                <span>Extension Preview</span>
                <button class="close-button">×</button>
            </div>
            <div class="extension-preview-content"></div>
        `;
        document.body.appendChild(this.extensionPreview);

        // Add close button handler
        this.extensionPreview.querySelector('.close-button').addEventListener('click', () => {
            this.hideExtensionPreview();
        });

        // Add drag functionality
        const header = this.extensionPreview.querySelector('.extension-preview-header');
        let isDragging = false;
        let currentX;
        let currentY;
        let initialX;
        let initialY;

        header.addEventListener('mousedown', (e) => {
            isDragging = true;
            initialX = e.clientX - this.extensionPreview.offsetLeft;
            initialY = e.clientY - this.extensionPreview.offsetTop;
        });

        document.addEventListener('mousemove', (e) => {
            if (isDragging) {
                e.preventDefault();
                currentX = e.clientX - initialX;
                currentY = e.clientY - initialY;
                this.extensionPreview.style.left = `${currentX}px`;
                this.extensionPreview.style.top = `${currentY}px`;
                this.extensionPreview.style.transform = 'none'; // Remove centering when dragging
            }
        });

        document.addEventListener('mouseup', () => {
            isDragging = false;
        });
    }

    showExtensionPreview(event, graph, sourceNode) {
        if (!graph || !graph.nodes) {
            console.error('Invalid graph data');
            return;
        }

        const preview = this.extensionPreview;
        
        // Position settings
        const windowWidth = window.innerWidth;
        const windowHeight = window.innerHeight;
        const previewWidth = 600;
        const previewHeight = 500;
        
        const left = Math.max(0, (windowWidth - previewWidth) / 2);
        const top = Math.max(0, (windowHeight - previewHeight) / 2);
        
        preview.style.display = 'block';
        preview.style.left = `${left}px`;
        preview.style.top = `${top}px`;
        preview.style.transform = 'none';
        
        // Get the content container
        const contentContainer = preview.querySelector('.extension-preview-content');
        contentContainer.innerHTML = '';
        
        // Format graph data with safety checks
        const formattedGraph = {
            nodes: graph.nodes.map(node => ({
                id: node.id || '',
                label: node.description || node.label || '',
                x: undefined,
                y: undefined
            })),
            edges: (graph.links || graph.edges || []).map(link => ({
                source: link.source || '',
                target: link.target || '',
                label: link.type || ''
            }))
        };

        // Create SVG and render graph
        const svg = d3.select(contentContainer)
            .append('svg')
            .attr('width', '100%')
            .attr('height', '100%');

        this.renderGraph(svg, formattedGraph, false, true, 0.8);
    }
    hideExtensionPreview() {
        if (this.extensionPreview) {
            this.extensionPreview.style.display = 'none';
        }
    }

    // Convert between graph formats
    convertGraphFormat(graph) {
        // Convert from new format to current format
        return {
            nodes: graph.nodes.map(node => ({
                id: node.id,
                label: node.description, // Use description as label
                x: undefined,
                y: undefined
            })),
            edges: (graph.links || []).map(link => ({
                id: `edge-${link.source}-${link.target}`,
                source: link.source,
                target: link.target,
                label: link.type
            }))
        };
    }

    // GraphExtension method
    async GraphExtension(newGraph) {
        try {
            const response = await fetch('http://localhost:5000/api/graph_extension', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    newGraph: newGraph
                })
            });
            const result = await response.json();
            if (result.status === 'success') {
                return result.data;
            } else {
                console.error('Failed to get extension graph:', result.message);
                return null;
            }
        } catch (error) {
            console.error('Failed to call GraphExtension API:', error);
            return null;
        }
    }

    generateRandomGraph() {
        const nodeCount = Math.floor(Math.random() * 3) + 3; // 3-5 nodes
        const nodes = [];
        const edges = [];

        for (let i = 0; i < nodeCount; i++) {
            nodes.push({
                id: `node-${i}`,
                label: `Node ${i}`,
                x: Math.random() * 500,
                y: Math.random() * 300
            });
        }

        for (let i = 0; i < nodeCount - 1; i++) {
            edges.push({
                id: `edge-${i}`,
                source: nodes[i].id,
                target: nodes[i + 1].id,
                label: `Edge ${i}`
            });
        }

        return { nodes, edges };
    }

    // Helper method to compute node levels
    computeNodeLevels(graph) {
        const levels = new Map();
        const visited = new Set();
        
        // Find root nodes (nodes with no incoming edges)
        const hasIncomingEdge = new Set(graph.edges.map(e => 
            typeof e.target === 'string' ? e.target : e.target.id));
        const rootNodes = graph.nodes.filter(n => !hasIncomingEdge.has(n.id));

        // Perform BFS to assign levels
        let currentLevel = 0;
        let currentNodes = rootNodes;

        while (currentNodes.length > 0) {
            const nextNodes = new Set();
            currentNodes.forEach(node => {
                if (!visited.has(node.id)) {
                    visited.add(node.id);
                    levels.set(node.id, currentLevel);
                    
                    // Find children
                    graph.edges.forEach(edge => {
                        const sourceId = typeof edge.source === 'string' ? edge.source : edge.source.id;
                        const targetId = typeof edge.target === 'string' ? edge.target : edge.target.id;
                        
                        if (sourceId === node.id) {
                            const targetNode = graph.nodes.find(n => n.id === targetId);
                            if (targetNode) nextNodes.add(targetNode);
                        }
                    });
                }
            });
            currentNodes = Array.from(nextNodes);
            currentLevel++;
        }

        // Handle any remaining nodes (for cyclic graphs)
        graph.nodes.forEach(node => {
            if (!levels.has(node.id)) {
                levels.set(node.id, currentLevel);
            }
        });

        return levels;
    }

    renderGraph(svg, graph, isEditable, isInitialRender = false, previewScale = 1) {
        if (!graph) return;
    
        svg.selectAll("*").remove();
        const width = svg.node().clientWidth;
        const height = svg.node().clientHeight;
    
        // 根据是否是预览图调整节点和文字大小
        const nodeRadius = 20 * previewScale;
        const fontSize = 12 * previewScale;
        const edgeLabelOffset = 5 * previewScale;
    
        // 只在初始渲染时设置固定位置
        if (isInitialRender) {
            graph.nodes.forEach((node, index) => {
                // 在整个可视区域内均匀分布节点
                const angle = (index / graph.nodes.length) * 2 * Math.PI;
                const radius = Math.min(width, height) * 0.3;
                node.x = width/2 + radius * Math.cos(angle);
                node.y = height/2 + radius * Math.sin(angle);
                // 固定节点位置
                node.fx = node.x;
                node.fy = node.y;
            });
        }
    
        // 创建节点映射
        const nodeMap = {};
        graph.nodes.forEach(node => {
            nodeMap[node.id] = node;
        });
    
        // 确保边的引用正确
        graph.edges.forEach(edge => {
            if (typeof edge.source === 'string') {
                edge.source = nodeMap[edge.source];
            }
            if (typeof edge.target === 'string') {
                edge.target = nodeMap[edge.target];
            }
        });
    
        // 调整力导向布局参数
        const simulation = d3.forceSimulation(graph.nodes)
            .force("link", d3.forceLink(graph.edges)
                .id(d => d.id)
                .distance(150)        // 增加连接距离
                .strength(0.7))      // 适当的连接强度
            .force("charge", d3.forceManyBody()
                .strength(-1000))    // 增加排斥力
            .force("center", d3.forceCenter(width / 2, height / 2)
                .strength(0.1))      // 添加中心力
            .force("collide", d3.forceCollide()
                .radius(80)          // 增加碰撞半径
                .strength(0.8))      // 增加碰撞强度
            .force("x", d3.forceX(width / 2).strength(0.1))
            .force("y", d3.forceY(height / 2).strength(0.1));
    
        // Draw edges
        const edges = svg.selectAll('.edge')
            .data(graph.edges)
            .enter()
            .append('g')
            .attr('class', 'edge');
    
        edges.append('line');
        edges.append('text')
            .text(d => d.label)
            .attr('text-anchor', 'middle')
            .attr('dy', -5);
    
        // Draw nodes
        const nodes = svg.selectAll('.node')
            .data(graph.nodes)
            .enter()
            .append('g')
            .attr('class', 'node');
    
        nodes.append('circle')
            .attr('r', 20);
    
        nodes.append('text')
            .text(d => d.label)
            .attr('text-anchor', 'middle')
            .attr('dy', 30);
    
        if (isEditable) {
            nodes.call(d3.drag()
                .on("start", dragstarted)
                .on("drag", dragged)
                .on("end", dragended));
    
            nodes.on('dblclick', (event, d) => {
                event.preventDefault();
                const textElement = d3.select(event.currentTarget).select('text');
                const foreignObject = d3.select(event.currentTarget)
                    .append('foreignObject')
                    .attr('x', -50)
                    .attr('y', 10)
                    .attr('width', 100)
                    .attr('height', 30);
    
                const input = foreignObject
                    .append('xhtml:input')
                    .attr('value', d.label)
                    .attr('style', 'width: 100%; height: 100%; text-align: center;')
                    .on('keypress', function(event) {
                        if (event.key === 'Enter') {
                            d.label = this.value;
                            textElement.text(d.label);
                            foreignObject.remove();
                        }
                    })
                    .on('blur', function() {
                        d.label = this.value;
                        textElement.text(d.label);
                        foreignObject.remove();
                    });
    
                input.node().focus();
            });
    
            d3.select('body').on('click', () => {
                d3.select('.context-menu').style('display', 'none');
            });
    
            nodes.on('contextmenu', (event, d) => {
                event.preventDefault();
                event.stopPropagation();
    
                const contextMenu = d3.select('.context-menu')
                    .style('display', 'block')
                    .style('left', `${event.pageX}px`)
                    .style('top', `${event.pageY}px`)
                    .html('');
    
                const menuItems = ['Delete Node', 'Add New Node', 'Add Edge', 'Extension'];
    
                contextMenu.selectAll('div')
                    .data(menuItems)
                    .enter()
                    .append('div')
                    .text(d => d)
                    .on('click', async (event, action) => {  // Add async here
                        switch(action) {
                            case 'Delete Node':
                                graph.nodes = graph.nodes.filter(n => n.id !== d.id);
                                graph.edges = graph.edges.filter(e => 
                                    e.source.id !== d.id && e.target.id !== d.id);
                                this.renderGraph(svg, graph, true);
                                break;
                            
                            case 'Add New Node':
                                const newNodeId = `node-${graph.nodes.length}`;
                                const newNode = {
                                    id: newNodeId,
                                    label: `Node ${graph.nodes.length}`,
                                    x: d.x + 100, // Increased offset
                                    y: d.y + 100  // Increased offset
                                };
                                graph.nodes.push(newNode);
                                this.renderGraph(svg, graph, true);
                                break;
                            
                            case 'Add Edge':
                                const sourceNode = d;
                                nodes.style('cursor', 'crosshair');
                                
                                const edgeListener = (event, targetNode) => {
                                    if (targetNode.id !== sourceNode.id) {
                                        const newEdge = {
                                            id: `edge-${graph.edges.length}`,
                                            source: sourceNode.id,
                                            target: targetNode.id,
                                            label: `Edge ${graph.edges.length}`
                                        };
                                        graph.edges.push(newEdge);
                                        this.renderGraph(svg, graph, true);
                                    }
                                    nodes.style('cursor', 'grab');
                                    nodes.on('click', null);
                                };
                                
                                nodes.on('click', edgeListener);
                                break;
                            // 在 case 'Extension' 部分
                            case 'Extension':
                                const extensionGraph = await this.GraphExtension(this.currentGraph);
                                if (extensionGraph) {
                                    // 确保在调用 showExtensionPreview 之前转换图形格式
                                    const formattedGraph = this.convertGraphFormat(extensionGraph);
                                    this.showExtensionPreview(event, formattedGraph, d);
                                }
                                break;
                        }
                        d3.select('.context-menu').style('display', 'none');
                    });
            });
    
            nodes.on('click', (event) => {
                event.stopPropagation();
            });
        }
    
        function dragstarted(event) {
            if (!event.active) simulation.alphaTarget(0.3).restart();
            event.subject.fx = event.subject.x;
            event.subject.fy = event.subject.y;
        }
    
        function dragged(event) {
            event.subject.fx = event.x;
            event.subject.fy = event.y;
        }
    
        function dragended(event) {
            if (!event.active) simulation.alphaTarget(0);
            // Store the final position instead of releasing it
            event.subject.x = event.subject.fx;
            event.subject.y = event.subject.fy;
        }
    
        simulation.on("tick", () => {
            edges.selectAll('line')
                .attr("x1", d => d.source.x)
                .attr("y1", d => d.source.y)
                .attr("x2", d => d.target.x)
                .attr("y2", d => d.target.y);
    
            edges.selectAll('text')
                .attr("x", d => (d.source.x + d.target.x) / 2)
                .attr("y", d => (d.source.y + d.target.y) / 2);
    
            nodes.attr("transform", d => `translate(${d.x},${d.y})`);
        });
    
        // Run simulation for a few ticks before rendering
        simulation.tick(10);
    }
    updateCurrentGraph(graph) {
        this.currentGraph = graph;
        this.renderGraph(this.currentGraphSvg, graph, true, true); // 设置为初始渲染
    }
    
    saveVersion() {
        if (this.currentGraph) {
            // Create a deep copy of the graph
            const graphCopy = {
                nodes: JSON.parse(JSON.stringify(this.currentGraph.nodes)),
                edges: this.currentGraph.edges.map(edge => ({
                    ...edge,
                    source: edge.source.id,
                    target: edge.target.id
                }))
            };
    
            const version = {
                number: this.currentVersion,
                graph: graphCopy,
                timestamp: new Date().toISOString()
            };
            this.versionHistory.push(version);
            this.currentVersion++;
            return version;
        }
        return null;
    }
    
    loadVersion(versionNumber) {
        const version = this.versionHistory.find(v => v.number === versionNumber);
        if (version) {
            this.currentGraph = JSON.parse(JSON.stringify(version.graph));
            
            // Fix edge references
            const nodeMap = {};
            this.currentGraph.nodes.forEach(node => {
                nodeMap[node.id] = node;
            });
            
            this.currentGraph.edges.forEach(edge => {
                if (typeof edge.source === 'string') {
                    edge.source = nodeMap[edge.source];
                }
                if (typeof edge.target === 'string') {
                    edge.target = nodeMap[edge.target];
                }
            });
            
            // 使用非初始渲染模式
            this.renderGraph(this.currentGraphSvg, this.currentGraph, true, false);
        }
    }
    
    getVersions() {
        return this.versionHistory;
    }
    
    clearVersions() {
        this.versionHistory = [];
        this.currentVersion = 0;
    }
    
    confirmCurrentGraph() {
        if (!this.currentGraph) return null;
        this.oldGraph = {
            nodes: JSON.parse(JSON.stringify(this.currentGraph.nodes)),
            edges: this.currentGraph.edges.map(edge => ({
                ...edge,
                source: typeof edge.source === 'object' ? edge.source.id : edge.source,
                target: typeof edge.target === 'object' ? edge.target.id : edge.target
            }))
        };
        // 渲染到上方区域，使用非初始渲染模式
        this.renderGraph(this.oldGraphSvg, this.oldGraph, false, false);
        
        // 保存到历史记录
        const graphState = {
            timestamp: new Date().toISOString(),
            operation: 'confirm',
            graph: this.oldGraph
        };
        this.graphHistory.push(graphState);
        localStorage.setItem('graphHistory', JSON.stringify(this.graphHistory));
        
        // 清理当前图形区域
        this.currentGraph = null;
        this.currentGraphSvg.selectAll("*").remove();
        
        // 清除版本历史
        this.clearVersions();
        
        return this.oldGraph;
    }
    
    // Rename the old save method to downloadHistory
    downloadHistory() {
        if (this.graphHistory.length > 0) {
            const historyBlob = new Blob(
                [JSON.stringify(this.graphHistory, null, 2)], 
                { type: 'application/json' }
            );
            const url = URL.createObjectURL(historyBlob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `graph_history_${new Date().toISOString().slice(0,10)}.json`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);
        }
    }
}