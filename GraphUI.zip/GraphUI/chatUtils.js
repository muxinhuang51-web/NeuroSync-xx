class ChatManager {
    constructor() {
        this.chatArea = document.getElementById('chatArea');
        this.messages = [];
        this.graphPreview = null;
        this.graphManager = new GraphManager();
        this.initGraphPreview();
        this.isPreviewVisible = false; // 添加预览状态标记
    }

    initGraphPreview() {
        // 创建预览窗口
        this.graphPreview = document.createElement('div');
        this.graphPreview.className = 'graph-preview';
        
        // 创建SVG容器
        const svg = d3.select(this.graphPreview)
            .append('svg')
            .attr('width', '100%')
            .attr('height', '100%');
            
        document.body.appendChild(this.graphPreview);
    }

    renderMessage(message) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${message.sender}-message`;
        
        // Add avatar
        const avatarDiv = document.createElement('div');
        avatarDiv.className = 'message-avatar';
        
        // 为AI消息添加悬停预览功能
        if (message.sender === 'ai' && this.graphManager.oldGraph) {
            avatarDiv.addEventListener('mouseenter', (e) => {
                this.showGraphPreview(e, this.graphManager.oldGraph);
            });
            
            avatarDiv.addEventListener('mouseleave', () => {
                this.hideGraphPreview();
            });
        }
        
        // Add message content
        const contentDiv = document.createElement('div');
        contentDiv.className = 'message-content';
        
        const senderDiv = document.createElement('div');
        senderDiv.style.fontWeight = 'bold';
        senderDiv.textContent = message.sender === 'user' ? 'User:' : 'AI:';
        
        const textDiv = document.createElement('div');
        textDiv.textContent = message.text;
        
        contentDiv.appendChild(senderDiv);
        contentDiv.appendChild(textDiv);
        
        messageDiv.appendChild(avatarDiv);
        messageDiv.appendChild(contentDiv);
        this.chatArea.appendChild(messageDiv);
        this.chatArea.scrollTop = this.chatArea.scrollHeight;
    }

    showGraphPreview(event, graph) {
        if (!graph || !graph.nodes || !graph.edges) {
            console.error('Invalid graph data');
            return;
        }

        const preview = this.graphPreview;
        
        // 清空之前的内容
        const svg = d3.select(preview.querySelector('svg'));
        svg.selectAll('*').remove();
        
        // 使用 GraphManager 的渲染方法
        this.graphManager.renderGraph(
            svg,
            {
                nodes: graph.nodes.map(node => ({...node})),
                edges: graph.edges.map(edge => ({...edge}))
            },
            false,  // 不可编辑
            true,   // 使用初始渲染模式
            0.6     // 设置较小的缩放比例
        );
        
        // 计算预览窗口位置
        const rect = event.target.getBoundingClientRect();
        
        // 将预览窗口定位在头像右侧
        let left = rect.right + 10;
        let top = rect.top;
        
        // 确保预览窗口在视口内
        if (left + 400 > window.innerWidth) {
            left = rect.left - 410; // 如果右侧放不下，就放在左侧
        }
        
        if (top + 300 > window.innerHeight) {
            top = window.innerHeight - 310;
        }
        
        preview.style.left = `${left}px`;
        preview.style.top = `${top}px`;
        preview.style.display = 'block';
    }

    hideGraphPreview() {
        if (this.graphPreview) {
            this.graphPreview.style.display = 'none';
        }
    }

    addMessage(text, sender, graphData = null) {
        const message = {
            id: Date.now(),
            text,
            sender,
            timestamp: new Date(),
            graphData
        };
        this.messages.push(message);
        this.renderMessage(message);
    }

    renderMessage(message) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${message.sender}-message`;
        
        // Add avatar
        const avatarDiv = document.createElement('div');
        avatarDiv.className = 'message-avatar';
        
        // 为AI消息添加悬停预览功能
        if (message.sender === 'ai') {
            avatarDiv.addEventListener('mouseenter', (e) => {
                const confirmedGraph = this.graphManager.oldGraph;
                if (confirmedGraph) {
                    this.showGraphPreview(e, confirmedGraph);
                }
            });
            
            avatarDiv.addEventListener('mouseleave', () => {
                this.hideGraphPreview();
            });
        }
        
        // Add message content
        const contentDiv = document.createElement('div');
        contentDiv.className = 'message-content';
        
        const senderDiv = document.createElement('div');
        senderDiv.style.fontWeight = 'bold';
        senderDiv.textContent = message.sender === 'user' ? 'User:' : 'AI:';
        
        const textDiv = document.createElement('div');
        textDiv.textContent = message.text;
        
        contentDiv.appendChild(senderDiv);
        contentDiv.appendChild(textDiv);
        
        messageDiv.appendChild(avatarDiv);
        messageDiv.appendChild(contentDiv);
        this.chatArea.appendChild(messageDiv);
        this.chatArea.scrollTop = this.chatArea.scrollHeight;
    }

    showGraphPreview(event, graphData) {
        const preview = this.graphPreview;
        
        // 设置预览窗口大小
        const scale = 0.4;
        const previewWidth = 400;
        const previewHeight = 300;
        
        // 更新预览窗口大小和样式
        preview.style.width = `${previewWidth}px`;
        preview.style.height = `${previewHeight}px`;
        preview.innerHTML = '';
        
        // 创建SVG容器
        const svg = d3.select(preview)
            .append('svg')
            .attr('width', '100%')
            .attr('height', '100%');
        
        // 使用传入的 graphData 创建图形
        const graph = {
            nodes: graphData.nodes.map(node => ({
                id: node.id,
                label: node.description
            })),
            edges: graphData.links.map(link => ({
                source: link.source,
                target: link.target,
                label: link.type
            }))
        };
    
        // 创建力导向布局
        const simulation = d3.forceSimulation(graph.nodes)
            .force("link", d3.forceLink(graph.edges).id(d => d.id).distance(100))
            .force("charge", d3.forceManyBody().strength(-200))
            .force("center", d3.forceCenter(previewWidth / 2, previewHeight / 2));
    
        // 创建连线
        const links = svg.append("g")
            .selectAll("line")
            .data(graph.edges)
            .enter()
            .append("line")
            .style("stroke", "#999")
            .style("stroke-width", 1);
    
        // 创建节点
        const nodes = svg.append("g")
            .selectAll("g")
            .data(graph.nodes)
            .enter()
            .append("g");
    
        nodes.append("circle")
            .attr("r", 20)
            .style("fill", "#69b3a2");
    
        nodes.append("text")
            .text(d => d.label)
            .attr('text-anchor', 'middle')
            .attr('dy', '.35em')
            .style('font-size', '12px');
    
        // 更新力导向布局
        simulation.on("tick", () => {
            links
                .attr("x1", d => d.source.x)
                .attr("y1", d => d.source.y)
                .attr("x2", d => d.target.x)
                .attr("y2", d => d.target.y);
    
            nodes.attr("transform", d => `translate(${d.x},${d.y})`);
        });
    
        // 计算预览窗口位置
        let left = event.pageX + 20;
        let top = event.pageY - previewHeight / 2;
        
        // 确保预览窗口在视口内
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;
        
        if (left + previewWidth > viewportWidth) {
            left = event.pageX - previewWidth - 20;
        }
        if (top + previewHeight > viewportHeight) {
            top = viewportHeight - previewHeight - 20;
        }
        if (top < 20) {
            top = 20;
        }
        
        preview.style.display = 'block';
        preview.style.left = `${left}px`;
        preview.style.top = `${top}px`;
    }

    hideGraphPreview() {
        this.graphPreview.style.display = 'none';
        this.isPreviewVisible = false;
    }

    getLastUserMessage() {
        const userMessages = this.messages.filter(m => m.sender === 'user');
        return userMessages[userMessages.length - 1];
    }
}