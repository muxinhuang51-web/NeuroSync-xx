document.addEventListener('DOMContentLoaded', () => {
    const graphManager = new GraphManager();
    const chatManager = new ChatManager();
    
    // 获取DOM元素
    const messageInput = document.getElementById('messageInput');
    const submitButton = document.getElementById('submitMessage');
    const confirmButton = document.getElementById('confirmGraph');
    const saveVersionButton = document.getElementById('saveVersion');
    const downloadButton = document.getElementById('downloadHistory');
    const versionSelect = document.getElementById('versionSelect');

    // 提交消息
    submitButton.addEventListener('click', async () => {  // 改为 async
        const text = messageInput.value.trim();
        if (text) {
            chatManager.addMessage(text, 'user');
            messageInput.value = '';
            
            // 测试后端 GraphCallFunction 接口
            try {
                const oldGraph = {
                    "nodes": [
                        {"id": "Node1", "description": "发起HTTP请求以获取目标网页的内容"},
                        // ... 其他节点
                    ],
                    "links": [
                        {"source": "Node1", "target": "Node2", "type": "parse"},
                        // ... 其他连接
                    ]
                };

                const response = await fetch('http://localhost:5000/api/graph_call', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        oldGraph: oldGraph,
                        userPrompt: text
                    })
                });
                
                const result = await response.json();
                console.log('GraphCallFunction Test Result:', result);
            } catch (error) {
                console.error('Failed to test GraphCallFunction:', error);
            }

            // 保持原有的随机图生成逻辑
            const newGraph = graphManager.generateRandomGraph();
            graphManager.updateCurrentGraph(newGraph);
        }
    });

    // 保存版本
    saveVersionButton.addEventListener('click', () => {
        const version = graphManager.saveVersion();
        if (version) {
            const option = document.createElement('option');
            option.value = version.number;
            option.textContent = `Version ${version.number} (${new Date(version.timestamp).toLocaleTimeString()})`;
            versionSelect.appendChild(option);
        }
    });

    // 加载版本
    versionSelect.addEventListener('change', () => {
        const versionNumber = parseInt(versionSelect.value);
        if (!isNaN(versionNumber)) {
            graphManager.loadVersion(versionNumber);
        }
    });

    // 确认图形
    confirmButton.addEventListener('click', async () => {
        const confirmedGraph = graphManager.confirmCurrentGraph();
        const lastUserMessage = chatManager.getLastUserMessage();
        
        // AI回复，包含图形数据和用户最后的消息
        const aiResponse = `Graph confirmed! 
            Current graph: ${JSON.stringify(confirmedGraph)}
            User's last message: ${lastUserMessage?.text}`;
        
        chatManager.addMessage(aiResponse, 'ai', confirmedGraph);

        // 调用后端接口保存历史记录
        try {
            const response = await fetch('http://localhost:5000/api/save_history', {  // Changed port to 5000
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    timestamp: new Date().toISOString(),
                    userMessage: lastUserMessage?.text || '',
                    aiResponse: aiResponse
                })
            });
            const result = await response.json();
            console.log('Save History Result:', result);
        } catch (error) {
            console.error('Failed to save history:', error);
        }
        
        // Clear version select options
        while (versionSelect.options.length > 1) {
            versionSelect.remove(1);
        }
        versionSelect.value = '';
    });

    // 下载历史记录
    downloadButton.addEventListener('click', () => {
        graphManager.downloadHistory();
    });

    // 支持按Enter发送消息
    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            submitButton.click();
        }
    });
});