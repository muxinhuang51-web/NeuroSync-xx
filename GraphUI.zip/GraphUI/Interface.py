import json

def GraphCallFunction(old_graph, user_prompt):
    try:
        # 这里是固定的返回图
        new_graph = {
            "nodes": [
                {"id": "Node1", "description": "发起HTTP请求以获取目标网页的内容"},
                {"id": "Node2", "description": "使用BeautifulSoup解析HTML"},
                {"id": "Node3", "description": "提取微信公众号文章中的正文内容"},
                {"id": "Node4", "description": "保存包含图片文件名的Markdown内容到 content.md"},
                {"id": "Node5", "description": "查找微信公众号文章中的所有图像"}
            ],
            "links": [
                {"source": "Node1", "target": "Node2", "type": "parse"},
                {"source": "Node2", "target": "Node3", "type": "extractText"},
                {"source": "Node2", "target": "Node5", "type": "findImages"}
            ]
        }
        return {"status": "success", "data": new_graph}
    except Exception as e:
        print(f"GraphCallFunction error: {str(e)}")  # 添加错误日志
        return {"status": "error", "message": str(e)}

def save_chat_history(user_message, ai_response):
    try:
        history_entry = {
            "userMessage": user_message,
            "aiResponse": ai_response
        }
        return {"status": "success", "message": "历史记录保存成功", "data": history_entry}
    except Exception as e:
        print(f"保存历史记录失败: {str(e)}")
        return {"status": "error", "message": str(e)}

def graph_extension(new_graph):
    try:
        # 固定返回的扩展图
        extension_graph = {
            "nodes": [
                {"id": "Node1", "description": "发起HTTP请求以获取目标网页的内容"},
                {"id": "Node2", "description": "使用BeautifulSoup解析HTML"},
                {"id": "Node3", "description": "提取微信公众号文章中的正文内容"},
                #{"id": "Node4", "description": "保存包含图片文件名的Markdown内容到 content.md"},
                {"id": "Node5", "description": "查找微信公众号文章中的所有图像"}
            ],
            "links": [
                {"source": "Node1", "target": "Node2", "type": "parse"},
                {"source": "Node2", "target": "Node3", "type": "extractText"},
                {"source": "Node2", "target": "Node5", "type": "findImages"}
            ]
        }
        return {"status": "success", "data": extension_graph}
    except Exception as e:
        return {"status": "error", "message": str(e)}